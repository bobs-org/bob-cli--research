## Prose comparison

::: {.annotation-trial}
| Option | Benefit | Limitation |
| --- | --- | --- |
| Local cache | Repeated reads avoid the network and continue working during a short outage. Select this complete sentence across its wrapped lines. | An invalidation policy is necessary because a saved response can become stale before the next refresh. |
| Live fetch | Each successful request uses the latest response from the service, which is useful when the data changes frequently. | A slow connection increases the wait before results appear, and an outage can prevent reading altogether. |

: Prose-oriented comparison: preserve every cell's meaning.
:::

## Numeric comparison

| Method | Median (ms) | P95 (ms) | Samples |
| :--- | ---: | ---: | ---: |
| A | 12.3 | 20.4 | 100 |
| B | 15.1 | 18.2 | 100 |

## Mixed content

| Name | Detail |
| --- | --- |
| Identity | The **office** field contains `ref_source_path`; café and naive text remain searchable. |
| Link | Read the [official guide](https://highlightsapp.net/how-to/mac/markup-pdf/) and preserve the link target. |
