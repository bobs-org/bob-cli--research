Independent cdx table-rendering research evidence, 2026-10-29.
Source bob-cli revision: 48253b7f225620f2cde10c856f458c31cd6f58d3.
Generated on Linux with Pandoc 3.1.3, XeTeX/TeX Live 2026, MuPDF 1.23.10.

Open baseline.pdf, widths_spacing.pdf, and linear_prose.pdf in Highlights.
These are controlled samples, not proof of selection behavior in Highlights.
No real failing user PDF or Apple runtime was available for this research.

experiment.py reconstructs source.md, filters, headers, TeX and PDFs:
  python3 experiment.py /path/to/bob-cli
Run it in an extracted disposable directory, because it rewrites its outputs.
The script reads Bob source files from the supplied checkout, but never invokes
Bob or writes to the vault. Use the revision above for equivalent render flags.
The fixture does not contain diagrams or fenced code; the three variants cover
one prose table (two body rows), one numeric table and one mixed-content table.
The style prototype is deliberately restricted to the marked fixture Div.
It does not implement generic table semantics or preserve automatic caption
numbering on the linearized table. Do not install its filter as production code.

summary.json records render results and PDF structure-tree presence.
cell_checks.json records whitespace-insensitive checks that each of 18 table
body cell strings occurs in MuPDF extraction. They are content integrity checks,
not measurements of interactive selection, Unicode fidelity or reading order
in PDFKit. *.lines.json contains MuPDF line text and bounding boxes.
*.catalog.json records the one external guide link (in an unchanged table).
