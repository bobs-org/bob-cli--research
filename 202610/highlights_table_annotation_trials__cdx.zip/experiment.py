"""Small rendering comparison, not a production table transform.

Run: python3 experiment.py /path/to/bob-cli
Requires pandoc, xelatex, mutool and the fonts/packages used by Bob.
Writes only beside this script. Never invokes bob or changes a vault.
"""
import json
import pathlib
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

repo = pathlib.Path(sys.argv[1]).resolve()
out = pathlib.Path(__file__).resolve().parent
source = r"""## Prose comparison

::: {.annotation-trial}
| Option | Benefit | Limitation |
| --- | --- | --- |
| Local cache | Repeated reads avoid the network and continue working during a short outage. Select this complete sentence across its wrapped lines. | An invalidation policy is necessary because a saved response can become stale before the next refresh. |
| Live fetch | Each successful request uses the latest response from the service, which is useful when the data changes frequently. | A slow connection increases the wait before results appear, and an outage can prevent reading altogether. |

: Prose-oriented comparison: preserve every cell's meaning.
:::

## Numeric comparison

| Method | Median (ms) | P95 (ms) | Samples |
| :--- | ---: | ---: | ---: |
| A | 12.3 | 20.4 | 100 |
| B | 15.1 | 18.2 | 100 |

## Mixed content

| Name | Detail |
| --- | --- |
| Identity | The **office** field contains `ref_source_path`; café and naive text remain searchable. |
| Link | Read the [official guide](https://highlightsapp.net/how-to/mac/markup-pdf/) and preserve the link target. |
"""
(out / "source.md").write_text(source)
create = (repo / "src/native/highlights_ref/create.rs").read_text()
header_decl = create.split("const PANDOC_HEADER_INCLUDES: &str = concat!(", 1)[1].split("\n);", 1)[0]
header = "\n".join(re.findall(r'^\s*r"(.*)",?$', header_decl, re.M))
for filename in ["return_links.tex", "diagrams.tex", "code_catalog.tex"]:
    header += "\n" + (repo / "src/native/highlights_ref" / filename).read_text()
(out / "header.tex").write_text(header)
code_break = create.split('const PANDOC_CODE_BREAK_FILTER: &str = r#"', 1)[1].split('"#;', 1)[0]
(out / "code_break.lua").write_text(code_break)

# Only the explicit fixture Div changes. Values remain Pandoc AST nodes.
width_filter = r"""
function Div(d)
  if not d.classes:includes('annotation-trial') then return nil end
  return d:walk({Table = function(t)
    for i, w in ipairs({0.16, 0.42, 0.42}) do t.colspecs[i][2] = w end
    return t
  end})
end
"""
linear_filter = r"""
function Div(d)
  if not d.classes:includes('annotation-trial') then return nil end
  return d:walk({Table = function(t)
    local blocks = pandoc.Blocks({})
    blocks:extend(t.caption.long)
    local labels = t.head.rows[1].cells
    for _, body in ipairs(t.bodies) do
      for _, row in ipairs(body.body) do
        for i, cell in ipairs(row.cells) do
          local inlines = pandoc.Inlines({pandoc.Strong(labels[i].contents[1].content), pandoc.Str(':'), pandoc.Space()})
          inlines:extend(cell.contents[1].content)
          blocks:insert(pandoc.Para(inlines))
        end
        blocks:insert(pandoc.RawBlock('latex', '\\medskip'))
      end
    end
    return blocks
  end})
end
"""
(out / "widths.lua").write_text(width_filter)
(out / "linear.lua").write_text(linear_filter)
(out / "spacing.tex").write_text(r"\AtBeginEnvironment{longtable}{\setlength{\tabcolsep}{9pt}\renewcommand{\arraystretch}{1.18}}")
base = ["pandoc", str(out / "source.md"), "-s", "-f", "markdown+autolink_bare_uris", "--toc", "--toc-depth=3", "--number-sections", "--pdf-engine=xelatex", "--preserve-tabs", "--highlight-style=tango"]
for key, value in [("colorlinks", "true"), ("linkcolor", "BobLinkInk"), ("urlcolor", "BobLinkInk"), ("filecolor", "BobLinkInk"), ("citecolor", "BobLinkInk"), ("geometry", "margin=0.85in"), ("fontsize", "10pt"), ("linestretch", "1.08"), ("mainfont", "DejaVu Serif"), ("sansfont", "DejaVu Sans"), ("monofont", "DejaVu Sans Mono"), ("mainfontoptions", "Ligatures=NoCommon"), ("sansfontoptions", "Ligatures=NoCommon"), ("monofontoptions", "Ligatures=NoCommon")]:
    base += ["-V", f"{key}={value}"]
base += ["--include-in-header", str(out / "header.tex")]
summary = {}
for variant in ["baseline", "widths_spacing", "linear_prose"]:
    cmd = list(base)
    cmd += ["-M", f"title=Table annotation trial: {variant}"]
    cmd += ["-M", f"bob-return-links-report={out / (variant + '.links.json')}", "-M", f"bob-code-report={out / (variant + '.catalog.json')}"]
    cmd += ["--lua-filter", str(repo / "src/native/highlights_ref/code_catalog.lua")]
    if variant == "widths_spacing":
        cmd += ["--lua-filter", str(out / "widths.lua"), "--include-in-header", str(out / "spacing.tex")]
    elif variant == "linear_prose":
        cmd += ["--lua-filter", str(out / "linear.lua")]
    cmd += ["--lua-filter", str(out / "code_break.lua"), "--lua-filter", str(repo / "src/native/highlights_ref/return_links.lua"), "--lua-filter", str(repo / "src/native/highlights_ref/code_catalog_report.lua")]
    for suffix in [".tex", ".pdf"]:
        r = subprocess.run(cmd + ["-o", str(out / (variant + suffix))], capture_output=True, text=True, cwd=out)
        (out / (variant + suffix + ".stderr")).write_text(r.stderr)
        if r.returncode:
            raise RuntimeError(r.stderr)
    subprocess.run(["mutool", "draw", "-F", "stext", "-o", str(out / (variant + ".xml")), str(out / (variant + ".pdf"))], check=True, capture_output=True)
    tree = ET.parse(out / (variant + ".xml"))
    pages = tree.findall("page")
    page_lines = []
    for page in pages:
        lines = []
        for line in page.iter("line"):
            text = "".join(c.attrib["c"] for c in line.iter("char"))
            lines.append({"text": text, "bbox": line.attrib.get("bbox")})
        page_lines.append(lines)
    (out / (variant + ".lines.json")).write_text(json.dumps(page_lines, indent=2, ensure_ascii=False))
    root = subprocess.run(["mutool", "show", str(out / (variant + ".pdf")), "trailer/Root"], capture_output=True, text=True, check=True).stdout
    summary[variant] = {"pages": len(pages), "bytes": (out / (variant + '.pdf')).stat().st_size, "page_sizes": [{"width": p.attrib["width"], "height": p.attrib["height"]} for p in pages], "has_struct_tree_root": "StructTreeRoot" in root, "stderr": (out / (variant + '.pdf.stderr')).read_text()}
(out / "summary.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
